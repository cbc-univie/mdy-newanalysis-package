Extension modules for MDAnalysis
Compile as:

python3 setup.py sdist
python3 setup.py install
